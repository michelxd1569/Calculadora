﻿namespace pryLP
{
    partial class frmCaso7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCaso7));
            this.label1 = new System.Windows.Forms.Label();
            this.lblVisor = new System.Windows.Forms.Label();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btmPunto = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btmCE = new System.Windows.Forms.Button();
            this.btnsuma = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnresta = new System.Windows.Forms.Button();
            this.btnSumatoria = new System.Windows.Forms.Button();
            this.btnFactorial = new System.Windows.Forms.Button();
            this.btnproducto = new System.Windows.Forms.Button();
            this.btnRaiz = new System.Windows.Forms.Button();
            this.btnCuadrado = new System.Windows.Forms.Button();
            this.btndivision = new System.Windows.Forms.Button();
            this.btnLog10 = new System.Windows.Forms.Button();
            this.btnRadian = new System.Windows.Forms.Button();
            this.btnSeno = new System.Windows.Forms.Button();
            this.btnCoseno = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Old English Text MT", 41.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(90, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 66);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calculadora 3.0";
            // 
            // lblVisor
            // 
            this.lblVisor.BackColor = System.Drawing.Color.White;
            this.lblVisor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVisor.Font = new System.Drawing.Font("Lucida Calligraphy", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVisor.ForeColor = System.Drawing.Color.Blue;
            this.lblVisor.Location = new System.Drawing.Point(12, 97);
            this.lblVisor.Name = "lblVisor";
            this.lblVisor.Size = new System.Drawing.Size(532, 123);
            this.lblVisor.TabIndex = 18;
            this.lblVisor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn7.Location = new System.Drawing.Point(12, 310);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(88, 56);
            this.btn7.TabIndex = 19;
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn1.Location = new System.Drawing.Point(12, 434);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(88, 56);
            this.btn1.TabIndex = 20;
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn4.Location = new System.Drawing.Point(12, 372);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(88, 56);
            this.btn4.TabIndex = 21;
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn0.Location = new System.Drawing.Point(12, 496);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(88, 56);
            this.btn0.TabIndex = 22;
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btmPunto
            // 
            this.btmPunto.BackColor = System.Drawing.Color.NavajoWhite;
            this.btmPunto.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F);
            this.btmPunto.Location = new System.Drawing.Point(125, 496);
            this.btmPunto.Name = "btmPunto";
            this.btmPunto.Size = new System.Drawing.Size(88, 56);
            this.btmPunto.TabIndex = 26;
            this.btmPunto.Text = ".";
            this.btmPunto.UseVisualStyleBackColor = false;
            this.btmPunto.Click += new System.EventHandler(this.btmPunto_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn5.Location = new System.Drawing.Point(125, 372);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(88, 56);
            this.btn5.TabIndex = 25;
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn2.Location = new System.Drawing.Point(125, 434);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(88, 56);
            this.btn2.TabIndex = 24;
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn8.Location = new System.Drawing.Point(125, 310);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(88, 56);
            this.btn8.TabIndex = 23;
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btnIgual
            // 
            this.btnIgual.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnIgual.Location = new System.Drawing.Point(237, 496);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(88, 56);
            this.btnIgual.TabIndex = 30;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = false;
            this.btnIgual.Click += new System.EventHandler(this.btnIgual_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn6.Location = new System.Drawing.Point(237, 372);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(88, 56);
            this.btn6.TabIndex = 29;
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn3.Location = new System.Drawing.Point(237, 434);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(88, 56);
            this.btn3.TabIndex = 28;
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.btn9.Location = new System.Drawing.Point(237, 310);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(88, 56);
            this.btn9.TabIndex = 27;
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btmCE
            // 
            this.btmCE.BackColor = System.Drawing.Color.NavajoWhite;
            this.btmCE.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F);
            this.btmCE.Location = new System.Drawing.Point(354, 311);
            this.btmCE.Name = "btmCE";
            this.btmCE.Size = new System.Drawing.Size(123, 46);
            this.btmCE.TabIndex = 31;
            this.btmCE.Text = "CE";
            this.btmCE.UseVisualStyleBackColor = false;
            this.btmCE.Click += new System.EventHandler(this.btmCE_Click);
            // 
            // btnsuma
            // 
            this.btnsuma.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnsuma.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.btnsuma.Location = new System.Drawing.Point(486, 310);
            this.btnsuma.Name = "btnsuma";
            this.btnsuma.Size = new System.Drawing.Size(57, 46);
            this.btnsuma.TabIndex = 32;
            this.btnsuma.Text = "+";
            this.btnsuma.UseVisualStyleBackColor = false;
            this.btnsuma.Click += new System.EventHandler(this.btnsuma_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F);
            this.btnC.Location = new System.Drawing.Point(354, 362);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(122, 46);
            this.btnC.TabIndex = 33;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnresta
            // 
            this.btnresta.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnresta.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.btnresta.Location = new System.Drawing.Point(486, 362);
            this.btnresta.Name = "btnresta";
            this.btnresta.Size = new System.Drawing.Size(57, 46);
            this.btnresta.TabIndex = 34;
            this.btnresta.Text = "-";
            this.btnresta.UseVisualStyleBackColor = false;
            this.btnresta.Click += new System.EventHandler(this.btnresta_Click);
            // 
            // btnSumatoria
            // 
            this.btnSumatoria.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnSumatoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F);
            this.btnSumatoria.Location = new System.Drawing.Point(354, 416);
            this.btnSumatoria.Name = "btnSumatoria";
            this.btnSumatoria.Size = new System.Drawing.Size(57, 66);
            this.btnSumatoria.TabIndex = 35;
            this.btnSumatoria.Text = "Σ";
            this.btnSumatoria.UseVisualStyleBackColor = false;
            this.btnSumatoria.Click += new System.EventHandler(this.btnSumatoria_Click);
            // 
            // btnFactorial
            // 
            this.btnFactorial.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnFactorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F);
            this.btnFactorial.Location = new System.Drawing.Point(419, 417);
            this.btnFactorial.Name = "btnFactorial";
            this.btnFactorial.Size = new System.Drawing.Size(57, 66);
            this.btnFactorial.TabIndex = 36;
            this.btnFactorial.Text = "n!";
            this.btnFactorial.UseVisualStyleBackColor = false;
            this.btnFactorial.Click += new System.EventHandler(this.btnFactorial_Click);
            // 
            // btnproducto
            // 
            this.btnproducto.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.btnproducto.Location = new System.Drawing.Point(486, 417);
            this.btnproducto.Name = "btnproducto";
            this.btnproducto.Size = new System.Drawing.Size(57, 66);
            this.btnproducto.TabIndex = 37;
            this.btnproducto.Text = "x";
            this.btnproducto.UseVisualStyleBackColor = false;
            this.btnproducto.Click += new System.EventHandler(this.btnproducto_Click);
            // 
            // btnRaiz
            // 
            this.btnRaiz.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnRaiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F);
            this.btnRaiz.Location = new System.Drawing.Point(354, 488);
            this.btnRaiz.Name = "btnRaiz";
            this.btnRaiz.Size = new System.Drawing.Size(57, 66);
            this.btnRaiz.TabIndex = 38;
            this.btnRaiz.Text = "√";
            this.btnRaiz.UseVisualStyleBackColor = false;
            this.btnRaiz.Click += new System.EventHandler(this.btnRaiz_Click);
            // 
            // btnCuadrado
            // 
            this.btnCuadrado.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnCuadrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnCuadrado.Location = new System.Drawing.Point(420, 488);
            this.btnCuadrado.Name = "btnCuadrado";
            this.btnCuadrado.Size = new System.Drawing.Size(57, 66);
            this.btnCuadrado.TabIndex = 39;
            this.btnCuadrado.Text = "x²";
            this.btnCuadrado.UseVisualStyleBackColor = false;
            this.btnCuadrado.Click += new System.EventHandler(this.btnCuadrado_Click);
            // 
            // btndivision
            // 
            this.btndivision.BackColor = System.Drawing.Color.NavajoWhite;
            this.btndivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.25F);
            this.btndivision.Location = new System.Drawing.Point(486, 488);
            this.btndivision.Name = "btndivision";
            this.btndivision.Size = new System.Drawing.Size(57, 66);
            this.btndivision.TabIndex = 40;
            this.btndivision.Text = "/";
            this.btndivision.UseVisualStyleBackColor = false;
            this.btndivision.Click += new System.EventHandler(this.btndivision_Click);
            // 
            // btnLog10
            // 
            this.btnLog10.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnLog10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnLog10.Location = new System.Drawing.Point(11, 244);
            this.btnLog10.Name = "btnLog10";
            this.btnLog10.Size = new System.Drawing.Size(109, 51);
            this.btnLog10.TabIndex = 41;
            this.btnLog10.Text = "log x";
            this.btnLog10.UseVisualStyleBackColor = false;
            this.btnLog10.Click += new System.EventHandler(this.btnLog10_Click);
            // 
            // btnRadian
            // 
            this.btnRadian.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnRadian.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnRadian.Location = new System.Drawing.Point(152, 243);
            this.btnRadian.Name = "btnRadian";
            this.btnRadian.Size = new System.Drawing.Size(109, 51);
            this.btnRadian.TabIndex = 42;
            this.btnRadian.Text = "π/180°";
            this.btnRadian.UseVisualStyleBackColor = false;
            this.btnRadian.Click += new System.EventHandler(this.btnRadian_Click);
            // 
            // btnSeno
            // 
            this.btnSeno.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnSeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btnSeno.Location = new System.Drawing.Point(293, 244);
            this.btnSeno.Name = "btnSeno";
            this.btnSeno.Size = new System.Drawing.Size(109, 51);
            this.btnSeno.TabIndex = 43;
            this.btnSeno.Text = "Sen(X)";
            this.btnSeno.UseVisualStyleBackColor = false;
            this.btnSeno.Click += new System.EventHandler(this.btnSeno_Click);
            // 
            // btnCoseno
            // 
            this.btnCoseno.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnCoseno.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btnCoseno.Location = new System.Drawing.Point(434, 244);
            this.btnCoseno.Name = "btnCoseno";
            this.btnCoseno.Size = new System.Drawing.Size(109, 51);
            this.btnCoseno.TabIndex = 44;
            this.btnCoseno.Text = "Cos(x)";
            this.btnCoseno.UseVisualStyleBackColor = false;
            this.btnCoseno.Click += new System.EventHandler(this.btnCoseno_Click);
            // 
            // frmCaso7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(555, 565);
            this.Controls.Add(this.btnCoseno);
            this.Controls.Add(this.btnSeno);
            this.Controls.Add(this.btnRadian);
            this.Controls.Add(this.btnLog10);
            this.Controls.Add(this.btndivision);
            this.Controls.Add(this.btnCuadrado);
            this.Controls.Add(this.btnRaiz);
            this.Controls.Add(this.btnproducto);
            this.Controls.Add(this.btnFactorial);
            this.Controls.Add(this.btnSumatoria);
            this.Controls.Add(this.btnresta);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnsuma);
            this.Controls.Add(this.btmCE);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btmPunto);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.lblVisor);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCaso7";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.frmCaso7_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVisor;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btmPunto;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btmCE;
        private System.Windows.Forms.Button btnsuma;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnresta;
        private System.Windows.Forms.Button btnSumatoria;
        private System.Windows.Forms.Button btnFactorial;
        private System.Windows.Forms.Button btnproducto;
        private System.Windows.Forms.Button btnRaiz;
        private System.Windows.Forms.Button btnCuadrado;
        private System.Windows.Forms.Button btndivision;
        private System.Windows.Forms.Button btnLog10;
        private System.Windows.Forms.Button btnRadian;
        private System.Windows.Forms.Button btnSeno;
        private System.Windows.Forms.Button btnCoseno;
    }
}