﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pryLP
{
    public partial class frmCaso7 : Form
    {
        public frmCaso7()
        {
            InitializeComponent();
        }

        // Variables Globales
        Boolean sw_operar = false;
        Boolean sw_punto = false;
        double n1 = 0, n2 = 0;
        double resul = 0;
        double nopc = 0;

        private void frmCaso7_Load(object sender, EventArgs e)
        {
            for(int x = 0; x <= 9; x++)
                this.Controls["btn"+x].Text = x.ToString();
        }

        // Método para digitar números
        private void Digitar(int digito)
        {
            if(sw_operar == true)
            {
                lblVisor.Text = "";
                sw_operar = false;
            }
            lblVisor.Text += digito.ToString();
        }

        // Optimizar el programa
        // Método cuando se presiona una operación
        private void Operar(int opc)
        {
            if(lblVisor.Text == "")
            {
                MessageBox.Show("Ingrese un Número", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);              
                return;
            }
            sw_operar = true;
            sw_punto = false;
            n1 = Convert.ToDouble(lblVisor.Text);
           
            nopc = opc;
        }

        // Operar
        private void btn0_Click(object sender, EventArgs e)
        {
            Digitar(0);
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Digitar(1);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Digitar(2);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            Digitar(3);
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Digitar(4);
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            Digitar(5);
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            Digitar(6);
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            Digitar(7);
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            Digitar(8);
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            Digitar(9);
        }

        private void btmCE_Click(object sender, EventArgs e)
        {
            string a = lblVisor.Text;

            if(lblVisor.Text != "")
            {
                lblVisor.Text = a.Remove(a.Length - 1);                
            }
        }

        private void btmPunto_Click(object sender, EventArgs e)
        {          
                if (lblVisor.Text == "")
                {
                    MessageBox.Show("Ingrese un Número antes de usar el separador decimal", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (sw_punto == false){
                    lblVisor.Text += ".";
                    sw_punto = true;
                }                     
        }
        private void btnsuma_Click(object sender, EventArgs e)
        {
            Operar(1);
        }

        private void btnresta_Click(object sender, EventArgs e)
        {
            Operar(2);
        }
        private void btnproducto_Click(object sender, EventArgs e)
        {
            Operar(3);
        }

        private void btndivision_Click(object sender, EventArgs e)
        {
            Operar(4);
        }
      
        private void btnIgual_Click(object sender, EventArgs e)
        {
            if (lblVisor.Text == "")
            {
                MessageBox.Show("Ingrese el Número a operar", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            n2 = Convert.ToDouble(lblVisor.Text);

            switch (nopc)
            {
                case 1:
                    resul =  n1 + n2;
                    break;

                case 2:
                    resul = n1 - n2;
                    break;

                case 3:
                    resul = n1 * n2;
                    break;

                case 4:
                    resul = n1 / n2;
                    break;
            }
            
            lblVisor.Text = resul.ToString();
            
            sw_operar = true;
            sw_punto = false;
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            lblVisor.Text = "";

            sw_operar = true;
            sw_punto = false;
        }

        // void opera
        private void result(int a)
        {
            if (lblVisor.Text == "")
            {
                MessageBox.Show("Ingrese un Número", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            n1 = Convert.ToDouble(lblVisor.Text);
            
            
            switch (a)
            {
                case 1:
                    float s = 0, c = 1;
                    
                    while (c <= n1)
                    {
                        s += c;

                        c++;
                    }
                    resul = s;
                    break;

                case 2:

                    float f = 1, c1 = 1;

                    while (c1 <= n1)
                    {
                        f *= c1;

                        c1++;
                    }
                    resul = f;
                    break;

                case 3:
                    resul = n1 * n1;
                    break;

                case 4:
                    resul = Math.Sqrt(n1);
                    break;

                case 5:
                    resul = Math.Log10(n1);
                    break;

                case 6:
                    resul = (Math.PI * n1)/ 180;
                    break;

                case 7:                   
                    resul = Math.Round(Math.Sin(Math.PI * n1 / 180),3);                   
                    break;

                case 8:                   
                    resul = Math.Round(Math.Cos(Math.PI * n1 / 180),3);
                    break;
            }
            lblVisor.Text = resul.ToString();
            sw_operar = true;
            sw_punto = false;

        }
        private void btnSumatoria_Click(object sender, EventArgs e)
        {
            result(1);
        }

        private void btnFactorial_Click(object sender, EventArgs e)
        {
            result(2);
        }

        private void btnCuadrado_Click(object sender, EventArgs e)
        {
            result(3);
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            result(4);
        }

        private void btnLog10_Click(object sender, EventArgs e)
        {
            result(5);
        }

        private void btnRadian_Click(object sender, EventArgs e)
        {
            result(6);
        }

        private void btnSeno_Click(object sender, EventArgs e)
        {
            result(7);
        }

        private void btnCoseno_Click(object sender, EventArgs e)
        {
            result(8);
        }
    }
}
